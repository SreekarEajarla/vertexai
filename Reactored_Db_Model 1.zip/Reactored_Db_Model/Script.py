import psycopg2
from dotenv import load_dotenv
import os

def run_sql_file_postgres():
    load_dotenv()

    host = os.getenv("PG_HOST")
    dbname = os.getenv("PG_DBNAME")
    user = os.getenv("PG_USER")
    password = os.getenv("PG_PASSWORD")
    port = os.getenv("PG_PORT", 5432)
    sql_file_path = os.getenv("SQL_FILE_PATH")

    try:
        conn = psycopg2.connect(
            host=host,
            dbname=dbname,
            user=user,
            password=password,
            port=port
        )
        cursor = conn.cursor()

        if not os.path.exists(sql_file_path):
            print(f"SQL file not found: {sql_file_path}")
            return

        with open(sql_file_path, 'r') as file:
            sql_script = file.read()

        cursor.execute(sql_script)
        conn.commit()
        print("SQL script executed successfully.")

    except psycopg2.errors.SyntaxError as syntax_err:
        print(f"Syntax Error: {syntax_err}")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

# Run
run_sql_file_postgres()
